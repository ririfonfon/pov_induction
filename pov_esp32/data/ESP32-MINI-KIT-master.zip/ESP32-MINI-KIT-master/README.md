# ESP32-MINI-KIT
This kit is based on esp-wroom-32.                                                                                           
The Mini-KIT guide is similar to ESP32-DEVKIT guide.
here:https://github.com/MHEtLive/arduino-esp32.                                                                               
And some popular shield is available for this esp32-Mini-Kit.                                                                 
Shield user guide uploading-------------                                                                                     
And the shields` examples has been uploaded.                                                                                 
Enjoy with esp32-Mini-Kit.
