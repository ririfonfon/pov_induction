POV display
====================
This is the main sketch for my version of a Persistance of Vision display for bikes
