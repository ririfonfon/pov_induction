ESPdotstar
===============
A sketch to test esp with dotstar library and a way to test your APA102 led strip, to see if there is any production errors and/or dead pixels
