Convert image to hex
=========
This python script is written by Phil Burgess and I've only made a few adjustments to it. 
You need python 2.7 and the library Pillow to run the script. I used pip to install the library on OS X 10.11.
