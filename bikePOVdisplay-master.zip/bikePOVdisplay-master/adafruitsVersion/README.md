ORIGINAL CODE FROM ADAFRUIT
==============================
Find full tutorial on https://learn.adafruit.com/bike-wheel-pov-display/overview


And again. Thank you so much for your work.
